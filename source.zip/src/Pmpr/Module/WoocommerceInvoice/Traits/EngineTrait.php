<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d08e58fa5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice\Traits; use Pmpr\Module\WoocommerceInvoice\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
