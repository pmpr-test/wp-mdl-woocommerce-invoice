<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfd89c15a4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice\Traits; use Pmpr\Module\WoocommerceInvoice\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
