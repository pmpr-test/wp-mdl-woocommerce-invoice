<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b8b742f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice\Traits; use Pmpr\Module\WoocommerceInvoice\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
