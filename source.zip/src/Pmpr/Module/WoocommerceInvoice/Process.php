<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d08e58fa5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { }
