<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b788153c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { }
