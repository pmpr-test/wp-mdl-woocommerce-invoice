<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d470adb879             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { }
