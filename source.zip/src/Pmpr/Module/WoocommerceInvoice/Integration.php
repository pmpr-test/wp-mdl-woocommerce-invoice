<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00ed3ef64             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\146\157\162\145\x5f\x69\x6e\166\x6f\151\143\145\x5f\143\157\x6e\x74\145\x6e\164", [$this, "\141\157\147\161\141\167\145\x61\x67\161\147\x63\x69\167\141\x6f"])->qcsmikeggeemccuu("\x61\146\164\145\162\137\x69\x6e\x76\x6f\x69\143\x65\137\x63\x6f\x6e\x74\x65\156\x74", [$this, "\147\161\x77\x73\155\x77\151\167\141\x73\171\155\x6b\143\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\x6c\137\x6c\141\156\147\165\x61\147\145", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
