<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b788153c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\146\x6f\x72\x65\x5f\151\156\x76\157\151\143\145\x5f\x63\157\x6e\x74\145\x6e\x74", [$this, "\141\x6f\147\x71\141\167\145\141\x67\x71\x67\143\151\x77\x61\157"])->qcsmikeggeemccuu("\x61\146\x74\x65\162\137\x69\156\166\x6f\151\x63\145\x5f\143\x6f\156\164\145\156\x74", [$this, "\147\x71\x77\163\155\167\x69\x77\x61\x73\x79\x6d\153\143\x73\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\x6c\x5f\x6c\x61\156\147\165\x61\147\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
