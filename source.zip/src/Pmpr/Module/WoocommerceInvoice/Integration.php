<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705de183e2f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\146\157\162\x65\x5f\151\156\x76\157\x69\143\x65\137\x63\157\156\x74\145\156\164", [$this, "\141\x6f\x67\x71\141\167\145\141\x67\161\x67\x63\x69\167\x61\x6f"])->qcsmikeggeemccuu("\141\x66\164\145\x72\137\x69\x6e\x76\157\151\143\x65\137\143\x6f\x6e\x74\145\x6e\x74", [$this, "\x67\x71\167\x73\x6d\x77\x69\x77\x61\x73\171\x6d\153\143\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\x6c\137\x6c\x61\156\x67\x75\x61\x67\145", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
