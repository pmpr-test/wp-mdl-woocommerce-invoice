<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5e9b747f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\146\x6f\162\x65\x5f\151\156\x76\x6f\x69\x63\x65\137\x63\157\x6e\164\145\156\x74", [$this, "\x61\x6f\x67\161\x61\167\x65\x61\x67\x71\x67\x63\151\167\141\x6f"])->qcsmikeggeemccuu("\x61\146\x74\x65\x72\137\x69\x6e\166\x6f\151\143\145\137\143\157\x6e\x74\145\x6e\x74", [$this, "\147\161\x77\x73\x6d\x77\x69\167\x61\163\x79\155\x6b\x63\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\154\137\154\141\x6e\x67\165\141\x67\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
