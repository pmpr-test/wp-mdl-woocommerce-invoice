<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b8b742f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\x66\x6f\x72\x65\137\x69\156\x76\x6f\x69\143\145\x5f\x63\x6f\156\x74\145\x6e\x74", [$this, "\x61\x6f\x67\161\x61\167\145\x61\147\x71\147\143\151\167\141\x6f"])->qcsmikeggeemccuu("\x61\146\164\x65\x72\137\151\x6e\166\x6f\151\143\x65\137\143\x6f\156\164\x65\156\164", [$this, "\147\x71\x77\163\155\167\x69\167\141\x73\171\155\153\143\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\154\x5f\x6c\141\x6e\x67\x75\141\x67\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
