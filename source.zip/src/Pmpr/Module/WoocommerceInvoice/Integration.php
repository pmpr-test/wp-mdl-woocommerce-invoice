<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ae1db5dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\x66\157\x72\145\137\151\156\x76\x6f\151\x63\x65\137\143\x6f\x6e\x74\145\x6e\x74", [$this, "\x61\157\x67\x71\x61\167\x65\141\147\161\147\x63\x69\167\141\x6f"])->qcsmikeggeemccuu("\141\x66\x74\145\x72\x5f\151\156\166\x6f\x69\x63\x65\x5f\x63\157\156\164\x65\156\x74", [$this, "\147\x71\x77\x73\x6d\x77\x69\167\x61\163\x79\x6d\x6b\143\x73\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\x6c\137\x6c\x61\156\x67\x75\x61\x67\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
