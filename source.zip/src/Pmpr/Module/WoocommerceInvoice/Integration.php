<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d08e58fa5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceInvoice; class Integration extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\146\x6f\162\145\x5f\151\156\x76\x6f\x69\143\x65\x5f\x63\x6f\156\x74\145\156\164", [$this, "\x61\157\147\161\141\x77\145\141\147\x71\x67\x63\x69\167\x61\x6f"])->qcsmikeggeemccuu("\141\146\164\x65\162\x5f\x69\x6e\x76\157\x69\x63\x65\x5f\143\x6f\156\x74\145\156\164", [$this, "\147\161\x77\x73\x6d\x77\x69\x77\141\163\171\155\x6b\143\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if ($sitepress) { $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\x6d\154\137\154\x61\x6e\x67\165\141\147\x65", $umwqusowiqmyseom); if ($swaukaagekiououo != '') { $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); } } } public function gqwsmwiwasymkcsi() { global $sitepress; if ($sitepress) { $sitepress->switch_lang($sitepress->get_default_language()); } } }
